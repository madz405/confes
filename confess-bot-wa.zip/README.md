# BOT CONFESS
> **Note** : Bot ini saya buat khusus untuk confess saja. Dan saya sarankan untuk menginstal bot ini pada replit, panel atau termux. Agar database confess nya tidak terhapus pada saat bot ke restart.

## UNTUK REPLIT
[![Run on Repl.it](https://repl.it/badge/github/zeeoneofficial/bot-confess-wa)](https://repl.it/github/zeeoneofficial/bot-confess-wa)
------

## UNTUK TERMUX & PANEL
Download sc nya [disini]()
